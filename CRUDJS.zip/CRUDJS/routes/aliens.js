// Import the express library and create a router object
const express = require('express');
const router = express.Router();

// Import the Alien model from the ../models/alien file
const Alien = require('../models/alien');

// Define a route for GET requests to the / endpoint
router.get('/:id', async (req, res) => {
      try {
          // Query the database for the Alien object with the specified ID and store the result in a variable
          const alien = await Alien.findById(req.params.id);
          // Send a JSON response containing the alien object
          res.json(alien);
      } catch (err) {
          // If an error occurs, send a response with an error message
          res.send('Error' + err);
      }
  });
  




// Define a route for POST requests to the / endpoint
router.post('/', async (req, res) => {
    const alien = new Alien({
        name: req.body.name,
        tech: req.body.name,
        sub: req.body.sub
    });

    try {
        const a1 = await alien.save();
        res.json(a1);
    } catch (err) {
        res.send('Error');
    }
});

// Export the router object so that it can be used in other parts of the application
module.exports = router;
