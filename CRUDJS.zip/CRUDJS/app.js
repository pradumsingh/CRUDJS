// Import the express and mongoose libraries
const express = require('express');
const mongoose = require('mongoose');

// Define the URL for the MongoDB database
const url = 'mongodb://localhost/AlienDBex';

// Create an instance of the express application
const app = express();

// Connect to the MongoDB database using the URL and some options
mongoose.connect(url, {useNewUrlParser:true});

// Store the connection object returned by mongoose.connect()
const con = mongoose.connection;

// Log a message to the console when the connection to the database is established
con.on('open', () => {
    console.log('connected...');
});
 
app.use(express.json())
// Import a router object from the ./routes/aliens file
const alienRouter = require('./routes/aliens');

// Mount the router object at the /aliens endpoint
app.use('/aliens', alienRouter);

// Start the server listening on port 9000 and log a message to the console
app.listen(30000, () => {
    console.log('Server started');
});
